package org.Annotations;

// Dependency Interface
public interface FortuneService {
	public String getFortune();
}
