package org.Annotations;

public interface Coach {
	public String getMessage();
	
	public String getyourFortune();
}
