package org.Annotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestBeanApp {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("AnnotationapplicationContext.xml");
		
		//BeanScope b1= context.getBean("beanScope",BeanScope.class);
		
		//BeanScope b2= context.getBean("beanScope",BeanScope.class);
		
		//System.out.println(b1==b2);
		
		//System.out.println(b1);
		
		//System.out.println(b2);
		
		//System.out.println(b1);
		//System.out.println(b2);
		
		context.close();

		//System.out.println(b2);
		//System.out.println(b2);
		
	}

}
