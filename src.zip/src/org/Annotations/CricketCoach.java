package org.Annotations;

import org.springframework.stereotype.Component;

//@Component("cricketCoach")   // cc is a Bean name (Bean ID)

@Component           // Default Bean Id is cricketCoach
public class CricketCoach implements Coach{

	
	@Override
	public String getMessage() {
		return "Message from Cricket Coach";
	}

	@Override
	public String getyourFortune() {
		// TODO Auto-generated method stub
		return null;
	}

}
