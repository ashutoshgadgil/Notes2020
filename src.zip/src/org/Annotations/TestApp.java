package org.Annotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("AnnotationapplicationContext.xml");

		//Coach c=context.getBean("cricketCoach",Coach.class);
		
		//System.out.println(c.getMessage());
		
		Coach c=context.getBean("tennisCoach",Coach.class);
		
		System.out.println(c.getMessage());
		
		System.out.println(c.getyourFortune());
		
		context.close();
	}

}
