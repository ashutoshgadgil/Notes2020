package org.Annotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

//@Component("tc")

@Component               // tennisCoach
public class TennisCoach implements Coach{

	// Field Injection
	@Autowired
	@Qualifier("sadFortuneService")
	private FortuneService fs;
	
	
	// Constructor Injection using Autowiring Concept
	/*
	@Autowired
	public TennisCoach(FortuneService fs) {   // TennisCoach ts=new TennisCoach(happyFortuneService);
		this.fs = fs;
	}
	
	*/

	
	// Setter Injection on applying @Autowired on the setter method
	
	/*
	@Autowired
	public void setFs(FortuneService fs) {
		this.fs = fs;
	}
	*/
	
	/*
	// Method Injection
	@Autowired
	void mymethod(FortuneService fs)
	{
		this.fs = fs;
	}
	*/
	
		
	@Override
	public String getMessage() {
		return "Message from Tennis Coach";
	}

	@Override
	public String getyourFortune() {
		return fs.getFortune();
	}

}
