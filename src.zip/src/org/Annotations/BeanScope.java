package org.Annotations;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class BeanScope {
	/*
	public BeanScope() 
	{
		System.out.println("Constructor called");
	}
	*/
	/*
	@PostConstruct
	public void construct()
	{
		System.out.println("Post construct called");
	}
	
	@PreDestroy
	public void destroy()
	{
		System.out.println("Pre destroy called");
	}
	*/
}
