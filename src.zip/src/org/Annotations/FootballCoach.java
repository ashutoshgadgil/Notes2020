package org.Annotations;

public class FootballCoach implements Coach{

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Message from Football coach";
	}

	@Override
	public String getyourFortune() {
		// TODO Auto-generated method stub
		return null;
	}

}
