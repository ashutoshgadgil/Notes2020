package org.pro;

public interface Cars {
	public String getSpecs();
}
