package org.pro;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class TestMain {

	public static void main(String[] args) {
		//BMW b=new BMW();
		
		//Scorpio s=new Scorpio();
		
		//Cars c=new Scorpio();    // Hardcoding
		
		// Step-1 : Load spring configuration file 
		//ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
			
		// Step-2 : Retrieve the bean from the container ,Use getBean() method
		//Cars c= context.getBean("carobj1",Cars.class); // new BMW();
		
		// Step-3 : Access methods of bean
		//System.out.println("Specifications : "+c.getSpecs());
		
		// Step-4 : Close the context object
		// context.close();
		
		// Use of BeanFactory(interface)  class (XmlBeanFactory)
				
		XmlBeanFactory context=new XmlBeanFactory(new ClassPathResource("applicationContext.xml"));
				
		Cars c= context.getBean("carobj",Cars.class);
		
		System.out.println(c.getSpecs());
		
		//System.out.println(c.getSpecs());
		
		
	}

}
