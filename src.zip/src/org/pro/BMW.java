package org.pro;

public class BMW implements Cars{
	public String getSpecs()
	{
		return "BMW Specifications";
	}
}
