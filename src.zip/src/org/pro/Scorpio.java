package org.pro;

public class Scorpio implements Cars{
	public String getSpecs()
	{
		return "Scorpio Specifications";
	}
}
