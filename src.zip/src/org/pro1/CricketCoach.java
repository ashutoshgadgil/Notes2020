package org.pro1;

public class CricketCoach implements Coach{

	private FortuneService fs;
	
	
	@Override
	public String getMessage() {
		return "Message from Cricket Coach";
	}

	@Override
	public String getYourFortune() {
		// TODO Auto-generated method stub
		return null;
	}

}
