package org.pro1;

public class FootballCoach implements Coach{

	@Override
	public String getMessage() {
		return "Message from Football Coach";
	}

	@Override
	public String getYourFortune() {
		// TODO Auto-generated method stub
		return null;
	}

}
