package org.pro1;

public interface FortuneService {
	public String getFortune();
}
