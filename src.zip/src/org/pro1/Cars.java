package org.pro1;

public interface Cars {
	public int getSpeed();
}
