package org.pro1;

public class TennisCoach implements Coach{

	private FortuneService fs;
	
	// Constructor where dependency injected
	public TennisCoach(FortuneService fs) {
		this.fs = fs;
	}
	
	@Override
	public String getMessage() {
		return "Message from Tennis coach";
	}

	@Override
	public String getYourFortune() {
		
		return fs.getFortune();
	}

}
