package org.pro1;

// Bean we want to inject in Coach class
public class HappyFortuneService implements FortuneService{

	@Override
	public String getFortune() {
		return "Your Lucky day today";
	}

}
