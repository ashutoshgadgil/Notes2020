package org.pro1;

public class BeanScope {

}
