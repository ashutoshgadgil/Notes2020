package org.pro1;

public interface Coach {
	public String getMessage();
	
	public String getYourFortune();
}
