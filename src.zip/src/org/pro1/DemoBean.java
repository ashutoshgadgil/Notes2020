package org.pro1;

public class DemoBean {

	private Cars c;

	private String model;
	
	private String color;
	
	
	public DemoBean() {
		
	}
	
	public void setC(Cars c) {
		this.c = c;
	}
	
	public int getCarSpeed()
	{
		return c.getSpeed();
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	
}
