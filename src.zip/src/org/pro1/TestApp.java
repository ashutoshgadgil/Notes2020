package org.pro1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {

	public static void main(String[] args) {
		
		// Loading of Spring configuration file
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");

		// Retrieve the bean object
		Coach c= context.getBean("mycoach",Coach.class);   // Coach c=new TennisCoach();
		
		System.out.println("Message : "+c.getMessage());
		
		System.out.println("Todays fortune : "+c.getYourFortune());
	}

}
