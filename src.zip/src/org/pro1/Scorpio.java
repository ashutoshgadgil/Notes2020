package org.pro1;

public class Scorpio implements Cars{

	@Override
	public int getSpeed() {
		return 120;
	}

}
