package org.pro1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCar {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext1.xml");
		
		DemoBean d= context.getBean("db",DemoBean.class);

		System.out.println("Model : "+d.getModel());
		
		System.out.println("Car Speed : "+d.getCarSpeed());
		
		System.out.println("Color : "+d.getColor());
		
		context.close();
	}

}
